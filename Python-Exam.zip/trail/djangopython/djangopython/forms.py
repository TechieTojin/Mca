from django import forms

class FeedbackForm(forms.Form):
    username = forms.CharField(label='User Name', max_length=100, widget=forms.TextInput(attrs={'placeholder': 'Enter your username'}))
    email = forms.EmailField(label='Email', widget=forms.EmailInput(attrs={'placeholder': 'Enter your email'}))
    password = forms.CharField(label='Password', widget=forms.PasswordInput(attrs={'placeholder': 'Enter your password'}))
    confirm_password = forms.CharField(label='Confirm Password', widget=forms.PasswordInput(attrs={'placeholder': 'Confirm your password'}))
    phone_number = forms.CharField(label='Phone Number', max_length=15, widget=forms.TextInput(attrs={'placeholder': 'Enter your phone number'}))
    feedback_message = forms.CharField(label='Feedback', widget=forms.Textarea(attrs={'placeholder': 'Enter your feedback'}))

    def clean(self):
        cleaned_data = super().clean()
        password = cleaned_data.get("password")
        confirm_password = cleaned_data.get("confirm_password")
        phone_number = cleaned_data.get("phone_number")

        if password != confirm_password:
            raise forms.ValidationError("Passwords do not match")

        if not phone_number.isdigit() or len(phone_number) < 10:
            raise forms.ValidationError("Phone number must contain only digits and be at least 10 characters long")
