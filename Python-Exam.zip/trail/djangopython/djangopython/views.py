from django.shortcuts import render
from .forms import FeedbackForm
def feedback_view(request):
    message = ''
    if request.method == 'POST':
        form = FeedbackForm(request.POST)
        if form.is_valid():
            message = 'Thank you for your feedback!'
            form = FeedbackForm()  # Reset form after successful submission
    else:
        form = FeedbackForm()

    return render(request, 'feedback/feedback_form.html', {'form': form, 'message': message})
